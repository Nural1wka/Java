package project.files.database;

public class DbConnectInfo {
    public static String DB_HOST = "localhost";
    public static String DB_PORT = "5432";
    public static String DB_USER = "postgres";
    public static String DB_PASS = "password";
    public static String DB_NAME = "market_place";
}
